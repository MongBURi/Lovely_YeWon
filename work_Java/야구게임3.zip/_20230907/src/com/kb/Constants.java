package com.kb;

public class Constants {
    public static final String MSG_INPUT_ANSWER_COUNT = "정답 개수 : ";
    public static final String MSG_INPUT_LIMIT = "입력 기회 : ";
    public static final String MSG_FIRST_INPUT = "첫번째 입력 : ";
    public static final String MSG_SECOND_INPUT = "두번째 입력 : ";
    public static final String MSG_THIRD_INPUT = "세번째 입력 : ";
}
